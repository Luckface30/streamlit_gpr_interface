import os
import numpy as np
import pandas as pd
import streamlit as st

def _safe_float(val, default=None):
    try:
        if val is None:
            return default
        v = float(val)
        return default if np.isnan(v) else v
    except Exception:
        return default

def _xcm_minmax(df: pd.DataFrame):
    if df is None or df.empty or "x_cm" not in df.columns:
        return None
    xcm = pd.to_numeric(df["x_cm"], errors="coerce").dropna()
    if xcm.empty:
        return None
    return float(np.nanmin(xcm.values)), float(np.nanmax(xcm.values))

def _filter_troncon(df: pd.DataFrame, xmin: float, xmax: float):
    if df is None or df.empty or "x_cm" not in df.columns:
        return pd.DataFrame()
    if xmin > xmax:
        xmin, xmax = xmax, xmin
    xcm = pd.to_numeric(df["x_cm"], errors="coerce")
    return df[(xcm >= xmin) & (xcm <= xmax)].copy()

def _rename_interfaces_for_unit(df: pd.DataFrame, unit: str):
    df = df.copy()
    for c in list(df.columns):
        if c.startswith("interface_"):
            df.rename(columns={c: f"{c}_{unit}"}, inplace=True)
    return df

def _export_excel(df: pd.DataFrame, unit: str, out_path: str, meta: dict = None):
    dirn = os.path.dirname(out_path)
    if dirn:
        os.makedirs(dirn, exist_ok=True)
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="stratigraphie", index=False)
        if meta:
            pd.DataFrame([meta]).to_excel(writer, sheet_name="meta", index=False)

def _convert_from_raw(df_raw: pd.DataFrame, unit: str, total_time_ns, real_height_px):
    """
    Convertit les profondeurs en ns si demandé.
    - Si real_height_px est fourni → conversion simple (facteur T/H).
    - Sinon, fallback ligne par ligne avec height_px si présent.
    - Sinon → retourne les valeurs brutes en px avec warning.
    """
    if df_raw is None or df_raw.empty:
        return pd.DataFrame()
    df = df_raw.copy(deep=True)
    if unit != "ns":
        return df

    T = _safe_float(total_time_ns, None)
    if T is None or T <= 0:
        st.warning("⚠️ Conversion en ns impossible : longueur image (ns) invalide.")
        return df

    interf_cols = [c for c in df.columns if c.startswith("interface_")]
    if not interf_cols:
        return df

    # Cas 1 : hauteur réelle donnée
    Hreal = _safe_float(real_height_px, None)
    if Hreal and Hreal > 0:
        factor = T / Hreal
        for c in interf_cols:
            df[c] = pd.to_numeric(df[c], errors="coerce") * factor
        return df

    # Cas 2 : fallback via height_px
    if "height_px" not in df.columns:
        st.warning("⚠️ Conversion en ns impossible : height_px absent et hauteur réelle non fournie.")
        return df

    H = pd.to_numeric(df["height_px"], errors="coerce")
    H = H.mask(H <= 0, np.nan)

    if H.isna().all():
        st.warning("⚠️ Conversion en ns impossible : height_px invalide partout.")
        return df

    for c in interf_cols:
        df[c] = (pd.to_numeric(df[c], errors="coerce") / H) * T

    return df

def _rolling_trend(df: pd.DataFrame, x_col: str, ycols: list, window_m: int = 5) -> pd.DataFrame:
    """
    Courbe de tendance robuste :
    - Fenêtre de `window_m` mètres (toujours en mètres)
    - Médiane par bin (robuste aux outliers)
    """
    if df is None or df.empty or x_col not in df.columns:
        return pd.DataFrame()

    # Fenêtre valide
    try:
        window_m = float(window_m)
    except Exception:
        window_m = 5.0
    if window_m <= 0:
        window_m = 5.0

    # Convertit l'abscisse en mètres pour le binning
    x_raw = pd.to_numeric(df[x_col], errors="coerce")
    if x_raw.isna().all():
        return pd.DataFrame()

    if x_col == "x_cm":
        x_m = x_raw / 100.0
    else:
        # suppose déjà en mètres si ce n'est pas x_cm
        x_m = x_raw

    # Index de bin en mètres
    x_bin = np.floor(x_m / window_m) * window_m

    # Prépare le tableau pour agrégation
    out = pd.DataFrame({"x_m": x_bin.astype(float)})
    for c in ycols:
        out[c] = pd.to_numeric(df[c], errors="coerce")

    g = out.groupby("x_m", as_index=False).median(numeric_only=True)
    return g.sort_values("x_m").reset_index(drop=True)

def _plot_stratigraphy(df: pd.DataFrame, title: str, unit_label: str, total_time_ns, 
                       style_choice: str, x_col: str = "x_cm", x_axis_label: str = None,
                       selected_interfaces=None, trend_window_m: int = 5):
    if selected_interfaces is None:
        ycols = [c for c in df.columns if c.startswith("interface_")]
    else:
        ycols = [c for c in selected_interfaces if c in df.columns]

    if not ycols or x_col not in df.columns or df.empty:
        st.info("Aucune donnée à tracer.")
        return

    import plotly.express as px
    import plotly.graph_objects as go

    # Base figure selon le style
    if style_choice == "Points":
        fig = px.scatter(df, x=x_col, y=ycols, title=title)

    elif style_choice == "Continu":
        fig = px.line(df, x=x_col, y=ycols, title=title)

    elif "Tendance" in style_choice:
        # afficher les points bruts si demandé
        if style_choice == "Tendance (avec points)":
            fig = px.scatter(df, x=x_col, y=ycols, title=title, opacity=0.4)
        else:
            fig = go.Figure(layout_title_text=title)

        # ajouter courbes de tendance lissées (binning en mètres, reprojection sur l'axe)
        for c in ycols:
            trend = _rolling_trend(df, x_col, [c], window_m=trend_window_m)
            if not trend.empty:
                # Reprojette la tendance dans l'unité de l'axe X
                if x_col == "x_cm":
                    x_trend = trend["x_m"] * 100.0  # cm
                else:  # "x_m" ou autres en mètres
                    x_trend = trend["x_m"]
                fig.add_scatter(x=x_trend, y=trend[c], mode="lines", name=f"Tendance {c}")

    else:
        fig = px.scatter(df, x=x_col, y=ycols, title=title)

    # Axes
    fig.update_xaxes(title=(x_axis_label or ("Position (cm)" if x_col == "x_cm" else "Position (m)")))
    if unit_label == "ns" and total_time_ns and total_time_ns > 0:
        fig.update_yaxes(title="Profondeur (ns)", autorange=False, range=[float(total_time_ns), 0.0])
    else:
        fig.update_yaxes(title=f"Profondeur ({unit_label})", autorange="reversed")

    st.plotly_chart(fig, use_container_width=True)
