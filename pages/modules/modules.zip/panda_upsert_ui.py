# pages/modules/panda_upsert_ui.py
import io
import difflib
import unicodedata
import numpy as np
import pandas as pd
import streamlit as st

from core.eps import get_eps1, get_eps2


# ==== Helpers ====
def _read_excel_with_sheet(upl, label_prefix: str) -> pd.DataFrame:
    try:
        xls = pd.ExcelFile(upl)
        sheet = st.selectbox(f"{label_prefix} • Feuille", xls.sheet_names, index=0, key=f"{label_prefix}_sheet")
        return pd.read_excel(xls, sheet_name=sheet)
    except Exception as e:
        st.error(f"Erreur de lecture Excel ({label_prefix}) : {e}")
        return pd.DataFrame()


def _coerce_numeric(s: pd.Series):
    return pd.to_numeric(s, errors="coerce")


def _maybe_round_pos(s: pd.Series) -> pd.Series:
    s = _coerce_numeric(s)
    if s.empty:
        return s
    try:
        if np.nanmax(np.abs(s - np.rint(s))) < 1e-6:
            return np.rint(s).astype(float)
    except ValueError:
        pass
    return s.astype(float)


def _safe_selectbox(label, options, defaults, key):
    opts = [o for o in (options or []) if o not in (None, "")]
    if not opts:
        st.selectbox(label, ["<aucune>"], index=0, key=key)
        return None
    def_norms = [str(d).lower() for d in (defaults or []) if d is not None]
    guess = next((c for c in opts if str(c).lower() in def_norms), opts[0])
    idx = opts.index(guess) if guess in opts else 0
    return st.selectbox(label, opts, index=idx, key=key)


def best_match_col(target, options):
    def strip_accents(t):
        return "".join(c for c in unicodedata.normalize("NFKD", str(t)) if not unicodedata.combining(c))
    def norm(t):
        return strip_accents(t).lower().replace("_", " ").strip()
    if not target or not options:
        return None
    n_target = norm(target)
    ratios = [(c, difflib.SequenceMatcher(None, n_target, norm(c)).ratio()) for c in options]
    ratios.sort(key=lambda t: t[1], reverse=True)
    return ratios[0][0] if ratios else None


# ==== Interpolation stricte: pas 10 cm, fenêtre ±2 m autour de CHAQUE point ====
def _last_valid(s: pd.Series):
    s2 = s.dropna()
    return s2.iloc[-1] if not s2.empty else np.nan


def interpolate_verites_windows(
    df: pd.DataFrame,
    pos_col: str,
    chosen_num_cols: list,
    chosen_non_cols: list,
    step: int = 10,
    half_window: int = 200,
) -> pd.DataFrame:
    """
    Construit la grille comme l'union des fenêtres [p-200, p+200] pour chaque position p,
    avec un pas EXACT de 10 cm. Interpole les colonnes numériques sur CHAQUE fenêtre,
    duplique (ffill/bfill) les colonnes texte sur la fenêtre. Puis agrège les
    recouvrements: moyenne pour numériques, dernière valeur non nulle pour textes.
    AUCUNE extrapolation hors fenêtres.
    """
    if df.empty or pos_col not in df.columns:
        return df

    # Nettoie et récupère les positions de base (au cm entier)
    pos_clean = pd.to_numeric(df[pos_col], errors="coerce").dropna()
    if pos_clean.empty:
        return df
    base_positions = np.unique(np.rint(pos_clean).astype(int))

    # Travail sur copie indexée par position
    work = df.copy()
    work[pos_col] = pd.to_numeric(work[pos_col], errors="coerce")
    work = work.dropna(subset=[pos_col]).set_index(pos_col).sort_index()

    # S'assure que les colonnes numériques sont bien converties en numérique
    for c in chosen_num_cols:
        if c in work.columns:
            work[c] = pd.to_numeric(work[c], errors="coerce")

    frames = []
    for p in base_positions:
        window_index = np.arange(p - half_window, p + half_window + 1, step)  # pas 10 cm

        # Numériques: interpolation linéaire dans la fenêtre
        if chosen_num_cols:
            w_num = work[chosen_num_cols].reindex(window_index).interpolate(
                method="index", limit_direction="both"
            )
        else:
            w_num = pd.DataFrame(index=window_index)

        # Textes: dupliquer valeurs dans la fenêtre
        if chosen_non_cols:
            w_txt = work[chosen_non_cols].reindex(window_index).ffill().bfill()
        else:
            w_txt = pd.DataFrame(index=window_index)

        win_df = pd.concat([w_num, w_txt], axis=1)
        frames.append(win_df)

    if not frames:
        return df

    union_df = pd.concat(frames, axis=0)

    # Agrégation des recouvrements
    agg = {c: "mean" for c in chosen_num_cols if c in union_df.columns}
    for c in chosen_non_cols:
        if c in union_df.columns:
            agg[c] = _last_valid

    out = union_df.groupby(level=0).agg(agg).reset_index().rename(columns={"index": pos_col, "level_0": pos_col})

    # Remet l'ordre colonnes: pos, (num), (textes)
    keep_order = [pos_col] + [c for c in chosen_num_cols if c in out.columns] + [c for c in chosen_non_cols if c in out.columns]
    out = out.reindex(columns=keep_order)
    return out


# ==== Bloc principal ====
def upsert_block():
    st.header("UPsert : mapping manuel/auto des colonnes (Cote touche, Eps, etc.)")

    # === A) Panda
    st.subheader("A. Charger **Panda**")
    upl_panda = st.file_uploader("Excel Panda (.xlsx/.xls)", type=["xlsx", "xls"], key="upl_panda_upsert")
    dfP, colsP = pd.DataFrame(), []
    if upl_panda is not None:
        dfP = _read_excel_with_sheet(upl_panda, "Panda")
        if not dfP.empty:
            st.success(f"Panda: {len(dfP)} lignes • {len(dfP.columns)} colonnes")
            with st.expander("Aperçu Panda"):
                st.dataframe(dfP.head(200), use_container_width=True)
            colsP = list(dfP.columns)

    pos_p = _safe_selectbox("Colonne de **position (cm)** → Panda", colsP,
                            ["position_cm", "x_cm", "position", "pos_cm"], "pos_col_p")

    # === B) Vérités
    st.subheader("B. Charger **Vérités terrain**")
    upl_T = st.file_uploader("Excel Vérités (.xlsx/.xls)", type=["xlsx", "xls"], key="upl_truth_upsert")
    dfT, colsT = pd.DataFrame(), []
    if upl_T is not None:
        dfT = _read_excel_with_sheet(upl_T, "Vérités")
        if not dfT.empty:
            st.success(f"Vérités: {len(dfT)} lignes • {len(dfT.columns)} colonnes")
            with st.expander("Aperçu Vérités (brut)"):
                st.dataframe(dfT.head(200), use_container_width=True)
            colsT = list(dfT.columns)

    pos_t = _safe_selectbox("Colonne de **position (cm)** → Vérités", colsT,
                            [pos_p, "position_cm", "x_cm", "position", "pos_cm"], "pos_col_t")

    # === C) Interpolation (pas 10 cm, ±2 m) + Eps
    st.subheader("C. Interpolation des Vérités terrain (10 cm, ±2 m)")

    T_enriched = pd.DataFrame()
    if not dfT.empty and pos_t:
        # Sélection des colonnes à traiter
        # Par défaut: numériques = dtype numérique; textes = le reste (hors pos)
        default_num = [c for c in dfT.columns if c != pos_t and pd.api.types.is_numeric_dtype(dfT[c])]
        default_txt = [c for c in dfT.columns if c not in default_num and c != pos_t]

        with st.expander("⚙️ Choisir les colonnes NUMÉRIQUES à interpoler (pas 10 cm)"):
            chosen_num_cols = st.multiselect("Numériques", options=[c for c in dfT.columns if c != pos_t], default=default_num)
        with st.expander("⚙️ Choisir les colonnes TEXTE à dupliquer (ffill/bfill)"):
            chosen_non_cols = st.multiselect("Textes", options=[c for c in dfT.columns if c != pos_t],
                                             default=[c for c in dfT.columns if c != pos_t and c not in chosen_num_cols])

        do_interp = st.checkbox("👉 Interpoler (pas 10 cm) sur ±2 m autour de CHAQUE point", value=False)
        if do_interp:
            T_enriched = interpolate_verites_windows(
                dfT.copy(), pos_t, chosen_num_cols, chosen_non_cols, step=10, half_window=200
            )
            st.success(f"Interpolation effectuée (pas 10 cm, ±2 m) : {len(T_enriched)} lignes.")
            with st.expander("Aperçu Vérités interpolées"):
                st.dataframe(T_enriched.head(200), use_container_width=True)
        else:
            T_enriched = dfT.copy()

        # ---- Eps après interpolation (optionnel) ----
        st.markdown("---")
        st.subheader("Compléter avec les eps (sur les données interpolées)")
        compute_eps = st.checkbox("Ajouter `Eps_1` et `Eps_2`", value=True)
        # L'utilisateur peut choisir quelles colonnes utiliser pour les règles
        all_cols_now = list(T_enriched.columns)
        hum_bs_col = _safe_selectbox("Colonne humidité **BS**", [c for c in all_cols_now if c != pos_t],
                                     ["humidite_bs", "hum_bs"], "hum_bs_after_interp")
        hum_bc_col = _safe_selectbox("Colonne humidité **BC**", [c for c in all_cols_now if c != pos_t],
                                     ["humidite_bc", "hum_bc"], "hum_bc_after_interp")
        colmat_col = _safe_selectbox("Colonne **colmatage**", [c for c in all_cols_now if c != pos_t],
                                     ["colmatage", "colm"], "colm_after_interp")
        obs_col = _safe_selectbox("Colonne **observations**", [c for c in all_cols_now if c != pos_t],
                                  ["obs", "observation"], "obs_after_interp")

        if compute_eps:
            def _val(r, c): return r.get(c) if (c and c in r.index) else None
            if hum_bs_col and obs_col and "Eps_1" not in T_enriched.columns:
                T_enriched["Eps_1"] = T_enriched.apply(
                    lambda r: get_eps1(str(_val(r, hum_bs_col)), str(_val(r, obs_col))), axis=1
                )
            if hum_bc_col and colmat_col and obs_col and "Eps_2" not in T_enriched.columns:
                T_enriched["Eps_2"] = T_enriched.apply(
                    lambda r: get_eps2(str(_val(r, hum_bc_col)), str(_val(r, colmat_col)), str(_val(r, obs_col))), axis=1
                )

            with st.expander("Voir Vérités interpolées + Eps"):
                st.dataframe(T_enriched.head(200), use_container_width=True)

    # === D) Mapping
    st.subheader("D. Correspondances de colonnes (Vérités ⟶ Panda)")
    mapped_cols = {}
    colsP_no_pos = [c for c in (colsP or []) if c != pos_p]
    colsT_enriched = list(T_enriched.columns) if not T_enriched.empty else (colsT or [])

    defaults_to_update = [c for c in ["Eps_1", "Eps_2", "interface_1", "interface_2",
                                      "Ballast Cote touche (m)", "Cote touche", "Cote touche (m)"]
                          if c in colsP_no_pos]
    commons = [c for c in colsP_no_pos if c in colsT_enriched]
    defaults_to_update += [c for c in commons if c not in defaults_to_update]

    cols_panda_to_update = st.multiselect("Colonnes Panda à alimenter/remplacer depuis Vérités",
                                          options=colsP_no_pos, default=defaults_to_update)
    if cols_panda_to_update:
        truth_choices = [c for c in colsT_enriched if c != pos_t]
        for pc in cols_panda_to_update:
            auto = best_match_col(pc, truth_choices)
            options = ["<aucune>"] + truth_choices
            idx = options.index(auto) if auto in options else 0
            mapped_cols[pc] = st.selectbox(f"Vérités → {pc}", options=options, index=idx, key=f"map_{pc}")

    # === E) Options
    round_positions = st.checkbox("Arrondir positions quasi entières", value=False)
    prefer_nulls = st.checkbox("Remplacer aussi par valeurs vides", value=False)
    dedup_truth = st.selectbox("Si Vérités a plusieurs lignes :",
                               ["Dernière valeur non nulle", "Première valeur non nulle", "Moyenne numérique"], index=0)

    # === F) Lancer
    if st.button("▶️ Lancer", key="btn_upsert"):
        if dfP.empty or dfT.empty or not pos_p or not pos_t:
            st.error("Charge Panda & Vérités et choisis les colonnes de position.")
            st.stop()

        P = dfP.copy()
        T = (T_enriched if not T_enriched.empty else dfT).copy()

        # 1) Mapping
        rename_map = {verites_col: panda_col for panda_col, verites_col in mapped_cols.items()
                      if verites_col and verites_col != "<aucune>" and verites_col in T.columns}
        if rename_map:
            T = T.rename(columns=rename_map)

        # 2) Clés
        P["_key_"] = _maybe_round_pos(P[pos_p]) if round_positions else _coerce_numeric(P[pos_p])
        T["_key_"] = _maybe_round_pos(T[pos_t]) if round_positions else _coerce_numeric(T[pos_t])

        # 3) Dédup Vérités
        T = T.dropna(subset=["_key_"])
        def _last_valid_group(s): s2 = s.dropna(); return s2.iloc[-1] if not s2.empty else np.nan
        def _first_valid_group(s): s2 = s.dropna(); return s2.iloc[0] if not s2.empty else np.nan
        if dedup_truth == "Dernière valeur non nulle":
            T = T.groupby("_key_", as_index=False).agg(_last_valid_group)
        elif dedup_truth == "Première valeur non nulle":
            T = T
        else:
            num_cols = [c for c in T.columns if c != "_key_" and pd.api.types.is_numeric_dtype(T[c])]
            agg = {c: "mean" for c in num_cols}
            for c in T.columns:
                if c not in num_cols and c != "_key_":
                    agg[c] = _last_valid_group
            T = T.groupby("_key_", as_index=False).agg(agg)

        # 4) Forcer schéma Panda
        panda_schema = [c for c in P.columns if c != "_key_"]
        keep_T_cols = set(["_key_", pos_t]) | set(panda_schema)
        T = T[[c for c in T.columns if c in keep_T_cols]].copy()

        # 5) Index
        P.set_index("_key_", inplace=True)
        T.set_index("_key_", inplace=True)

        # 6) Colonnes à remplacer
        if cols_panda_to_update:
            cols_sel = [c for c in cols_panda_to_update if c in P.columns and c in T.columns and c != pos_p]
        else:
            cols_sel = [c for c in P.columns if c in T.columns and c != pos_p]

        # 7) Remplacement
        inter = P.index.intersection(T.index)
        if prefer_nulls:
            if cols_sel:
                P.loc[inter, cols_sel] = T.loc[inter, cols_sel]
        else:
            for c in cols_sel:
                mask = T.loc[inter, c].notna()
                idx = mask[mask].index
                if len(idx) > 0:
                    P.loc[idx, c] = T.loc[idx, c]

        # 8) Ajout nouvelles positions
        only_T = T.index.difference(P.index)
        if len(only_T) > 0:
            new_rows = T.loc[only_T].copy()
            if pos_p not in new_rows.columns:
                new_rows[pos_p] = new_rows.index
            else:
                new_rows[pos_p] = new_rows[pos_p].where(~new_rows[pos_p].isna(), new_rows.index)
            new_rows = new_rows.reindex(columns=P.columns, fill_value=np.nan)
            P = pd.concat([P, new_rows], axis=0, ignore_index=False)

        # 9) Finalisation
        P.reset_index(drop=False, inplace=True)
        if pos_p not in P.columns:
            P[pos_p] = P["_key_"]
        else:
            P[pos_p] = P[pos_p].where(~P[pos_p].isna(), P["_key_"])
        P.drop(columns=["_key_"], inplace=True, errors="ignore")

        panda_order = [c for c in dfP.columns if c in P.columns and c != pos_p]
        others = [c for c in P.columns if c not in panda_order and c != pos_p]
        P = P[[pos_p] + panda_order + others]

        try:
            P[pos_p] = _coerce_numeric(P[pos_p])
            P.sort_values(by=pos_p, inplace=True)
        except Exception:
            pass

        st.success("UPsert + mapping terminé ✅ — schéma strictement identique à Panda.")
        with st.expander("Aperçu résultat"):
            st.dataframe(P.head(200), use_container_width=True)

        st.session_state["panda_upsert_df"] = P

        bio = io.BytesIO()
        with pd.ExcelWriter(bio, engine="openpyxl") as w:
            P.to_excel(w, sheet_name="panda_upsert", index=False)
        bio.seek(0)
        st.download_button("💾 Télécharger l'Excel fusionné (UPsert + mapping)",
                           data=bio,
                           file_name="panda_upsert.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
