# core/eps.py
import numpy as np
import pandas as pd
from typing import Tuple, Optional

# ============================================================
# Config de quantification
# ============================================================
STEP = 0.2  # pas de variation désiré (ε)
INDICATOR_STEP = 1.0  # pas pour l'indicateur (entier)

def _quantize(x: float, step: float = STEP) -> float:
    """
    Quantifie x au pas 'step' et formate à 1 décimale.
    Exemple: step=0.2 -> ... 4.2, 4.4, 4.6 ...
    """
    return round(round(x / step) * step, 1)

# Générateur aléatoire (non déterministe à chaque appel)
_rng = np.random.default_rng()

# ============================================================
# Tables intégrées (issues des Excel d’origine)
# ============================================================
# NB: on intègre maintenant aussi la plage d'INDICATEUR (min/max)
# Les colonnes sont:
#   0: observation (str)
#   1: humidite (str) — "-" pour joker
#   2: nature_colmatage (str) — "-" pour joker
#   3: eps_min (float)
#   4: eps_max (float)
#   5: ind_min (float | NaN) — NaN si "< X" (borne inf absente)
#   6: ind_max (float | NaN) — NaN si "> X" (borne sup absente)

# EPS1 (BS)
_EPS1_RULES = pd.DataFrame([
    # Glaise/argile/remontée dans BS
    ("glaiseuse/argileuse/remontee dans bs", "-",   "-",   8.0, 10.0, 22.0, 45.0),

    # Pollution diffuse dans BS (spécifique par humidité)
    ("pollution diffuse dans bs",           "sec", "-",    4.0,  5.5,  4.0, 10.0),
    ("pollution diffuse dans bs",           "hum", "-",    4.5,  6.0,  4.0, 10.0),
    ("pollution diffuse dans bs",           "sat", "-",   10.0, 14.0,  4.0, 10.0),

    # Variante générique si l'humidité n'est pas renseignée
    ("pollution diffuse dans bs",           "-",   "-",    4.5,  6.0,  4.0, 10.0),

    # Observation ne mentionne pas BS
    ("observation ne mentionne pas bs",     "sec", "-",    3.5,  4.5,  np.nan,  2.0),  # « < 2 »
    ("observation ne mentionne pas bs",     "hum", "-",    4.5,  6.0,  np.nan,  2.0),  # « < 2 »
    ("observation ne mentionne pas bs",     "sat", "-",   10.0, 14.0,  2.0,  4.0),
])

# EPS2 (BC)
_EPS2_RULES = pd.DataFrame([
    # Glaise/argile/remontée (colmatage gl ou non précisé)
    ("glaiseuse/argileuse/remontee",        "-",   "-",   11.0, 13.0, 55.0, 70.0),
    ("glaiseuse/argileuse/remontee",        "hum", "gl",  10.0, 14.0, 55.0, 70.0),
    ("glaiseuse/argileuse/remontee",        "sat", "gl",  10.0, 14.0, 55.0, 70.0),

    # Pollution diffuse dans BC (nature « n »)
    ("pollution diffuse dans bc",            "sec", "n",    6.0,  7.5, 12.0, 20.0),
    ("pollution diffuse dans bc",            "hum", "n",    8.0, 10.0, 12.0, 20.0),
    ("pollution diffuse dans bc",            "sat", "n",   11.0, 13.0, 22.0, 45.0),

    # Pollution diffuse dans BC (colmatage gl)
    ("pollution diffuse dans bc",            "hum", "gl",  10.0, 14.0, 55.0, 70.0),
    ("pollution diffuse dans bc",            "sat", "gl",  10.0, 14.0, 55.0, 70.0),

    # Pollution diffuse dans BC (colmatage non précisé — fallback utile)
    ("pollution diffuse dans bc",            "sec", "-",    6.0,  7.5, 12.0, 20.0),
    ("pollution diffuse dans bc",            "hum", "-",    7.6,  8.9, 12.0, 20.0),
    ("pollution diffuse dans bc",            "sat", "-",   10.0, 14.0, 22.0, 45.0),

    # Cas générique
    ("autres",                                "-",   "-",    7.0,  9.0,  np.nan, np.nan),
])

# ============================================================
# Matching générique
# ============================================================

def _match_row(df: pd.DataFrame, obs: str, hum: str, colm: str = "-") -> Optional[pd.Series]:
    """Retourne la première ligne qui matche (obs, hum, colm)."""
    obs = (obs or "").lower()
    hum = (hum or "-").lower()
    colm = (colm or "-").lower()

    # Sélection par observation (contains)
    sub = df[df[0].apply(lambda s: s in obs)]
    if sub.empty:
        sub = df[df[0] == "autres"]
    if sub.empty:
        sub = df

    # Filtrage humidité + colmatage, avec jokers
    r = sub[(sub[1] == hum) & (sub[2] == colm)]
    if r.empty: r = sub[(sub[1] == hum) & (sub[2] == "-")]
    if r.empty: r = sub[(sub[1] == "-")   & (sub[2] == colm)]
    if r.empty: r = sub[(sub[1] == "-")   & (sub[2] == "-")]

    if r.empty:
        return None
    return r.iloc[0]

# ============================================================
# API publique — intervalles ε et INDICATEUR
# ============================================================

def _to_tuple(a: float, b: float) -> Tuple[Optional[float], Optional[float]]:
    """Convertit des floats (dont NaN) en (Optional[float], Optional[float])."""
    return (None if (a is None or pd.isna(a)) else float(a),
            None if (b is None or pd.isna(b)) else float(b))

# --- EPS1 (BS)

def get_eps1_interval(humidite_bs: str, obs: str) -> Tuple[Optional[float], Optional[float]]:
    """Retourne (min, max) de la plage ε1 pour la combinaison donnée."""
    row = _match_row(_EPS1_RULES, obs, humidite_bs)
    if row is None:
        return (None, None)
    return _to_tuple(row[3], row[4])


def get_eps1_indicator_interval(humidite_bs: str, obs: str) -> Tuple[Optional[float], Optional[float]]:
    """Retourne (min, max) de la plage *indicateur* associée à ε1 (BS).
    Si la borne inf n'existe pas (cas « < X »), min=None.
    """
    row = _match_row(_EPS1_RULES, obs, humidite_bs)
    if row is None:
        return (None, None)
    return _to_tuple(row[5], row[6])


def get_eps1(humidite_bs: str, obs: str, jitter: float = 0.0) -> float:
    """
    Tirage **aléatoire** uniforme dans [min, max], puis quantification au pas 0.2.
    `jitter` conservé pour compatibilité mais ignoré.
    """
    row = _match_row(_EPS1_RULES, obs, humidite_bs)
    if row is None:
        return float("nan")
    a, b = float(row[3]), float(row[4])
    if pd.isna(a) or pd.isna(b) or b < a:
        return float("nan")
    # tirage uniformément dans [a, b]
    val = a + _rng.random() * (b - a)
    # quantifie puis clamp dans [a, b]
    q = _quantize(val, STEP)
    return float(min(max(q, a), b))


def sample_eps1_with_indicator(humidite_bs: str, obs: str) -> Tuple[float, Optional[float]]:
    """Échantillonne ε1 et calcule l'indicateur par interpolation linéaire
    au même pourcentage d'avancement, puis **quantifie l'indicateur au pas 1**.

    Cas particulier: si l'intervalle d'indicateur est « < 2 », on interprète
    cela comme [0, 2] avant interpolation.
    """
    row = _match_row(_EPS1_RULES, obs, humidite_bs)
    if row is None:
        return (float("nan"), None)

    a, b = float(row[3]), float(row[4])  # eps min/max
    ia, ib = row[5], row[6]              # ind min/max (peuvent être NaN)
    if pd.isna(a) or pd.isna(b) or b <= a:
        return (float("nan"), None)

    # échantillonnage ε1
    eps = _quantize(a + _rng.random() * (b - a), STEP)
    eps = float(min(max(eps, a), b))

    # Prépare bornes indicateur (gère « < 2 » -> [0, 2])
    if pd.isna(ia) and not pd.isna(ib) and float(ib) == 2.0:
        ia = 0.0  # borne inf spécifiée par la consigne
    if pd.isna(ia) or pd.isna(ib):
        # si on n'a toujours pas les deux bornes, on ne peut pas interpoler
        # -> renvoyer la borne connue quantifiée
        known = ib if pd.isna(ia) else ia
        return (eps, None if pd.isna(known) else _quantize(float(known), INDICATOR_STEP))

    ia, ib = float(ia), float(ib)
    # interpolation puis quantification au pas 1
    t = (eps - a) / (b - a)
    ind = ia + t * (ib - ia)
    ind = _quantize(ind, INDICATOR_STEP)
    # clamp dans [ia, ib]
    ind = float(min(max(ind, ia), ib))
    return (eps, ind)

# --- EPS2 (BC)

def get_eps2_interval(humidite_bc: str, colmatage: str, obs: str) -> Tuple[Optional[float], Optional[float]]:
    """Retourne (min, max) de la plage ε2 pour la combinaison donnée."""
    row = _match_row(_EPS2_RULES, obs, humidite_bc, colmatage)
    if row is None:
        return (None, None)
    return _to_tuple(row[3], row[4])


def get_eps2_indicator_interval(humidite_bc: str, colmatage: str, obs: str) -> Tuple[Optional[float], Optional[float]]:
    """Retourne (min, max) de la plage *indicateur* associée à ε2 (BC).
    Si la borne inf n'existe pas (cas « < X »), min=None.
    """
    row = _match_row(_EPS2_RULES, obs, humidite_bc, colmatage)
    if row is None:
        return (None, None)
    return _to_tuple(row[5], row[6])


def get_eps2(humidite_bc: str, colmatage: str, obs: str, jitter: float = 0.0) -> float:
    """
    Tirage **aléatoire** uniforme dans [min, max], puis quantification au pas 0.2.
    `jitter` conservé pour compatibilité mais ignoré.
    """
    row = _match_row(_EPS2_RULES, obs, humidite_bc, colmatage)
    if row is None:
        return float("nan")
    a, b = float(row[3]), float(row[4])
    if pd.isna(a) or pd.isna(b) or b < a:
        return float("nan")
    val = a + _rng.random() * (b - a)
    q = _quantize(val, STEP)
    return float(min(max(q, a), b))


def sample_eps2_with_indicator(humidite_bc: str, colmatage: str, obs: str) -> Tuple[float, Optional[float]]:
    """Échantillonne ε2 puis calcule l'indicateur par interpolation linéaire
    au même pourcentage d'avancement; **quantification au pas 1** sur l'indicateur.
    """
    row = _match_row(_EPS2_RULES, obs, humidite_bc, colmatage)
    if row is None:
        return (float("nan"), None)

    a, b = float(row[3]), float(row[4])
    ia, ib = row[5], row[6]
    if pd.isna(a) or pd.isna(b) or b <= a:
        return (float("nan"), None)

    eps = _quantize(a + _rng.random() * (b - a), STEP)
    eps = float(min(max(eps, a), b))

    # bornes indicateur normales
    if pd.isna(ia) or pd.isna(ib):
        known = ib if pd.isna(ia) else ia
        return (eps, None if pd.isna(known) else _quantize(float(known), INDICATOR_STEP))

    ia, ib = float(ia), float(ib)
    t = (eps - a) / (b - a)
    ind = ia + t * (ib - ia)
    ind = _quantize(ind, INDICATOR_STEP)
    ind = float(min(max(ind, ia), ib))
    return (eps, ind)
