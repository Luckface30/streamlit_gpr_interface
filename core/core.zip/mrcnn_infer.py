# core/mrcnn_infer.py
"""
Module d'inférence Mask R-CNN pour la détection d'interfaces.
Inclut :
- Chargement de deux modèles Mask R-CNN
- Filtrage et fusion morphologique des masques
- Application de seuils métier (38 / 52 px)
- Export overlays, masques binaires, colormaps, JSON positions, Excel interfaces
"""

import os
import re
import json
from typing import List, Tuple, Optional, Dict

import cv2
import numpy as np
import pandas as pd
from PIL import Image

import torch
from torchvision.models.detection import maskrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor


__all__ = [
    "list_image_files",
    "parse_image_name",
    "classify_files_by_pk",
    "has_existing_inference",
    "aggregate_excels_to_stratigraphy",
    "run_inference_for_category",
]


# ===================== Configuration ===================== #
CM_STEP = 10
EXPECTED_POINTS = 40

# Règles interfaces
THR_INTERFACE0 = 38.0
THR_FORBIDDEN1 = 52.0

# Seuils morpho/filtrage
ASPECT_RATIO_THR = 50.0
MIN_HEIGHT_PX = 2
MIN_WIDTH_PX = 100  # largeur horizontale minimale (px)

# Paramètres par défaut alignés sur l’UI
DEFAULT_PARAMS = {
    "score_thr": 0.40,
    "pixel_thr": 0.40,
    "pre_split_dilate_px": 0,
    "fuse_dilate_iter": 2,
    "fuse_kernel_size": (9, 3),
    "fuse_horizontal_boost": True,
    "hline_len": 30,
    "hline_thick": 3,
    "hline_close_iters": 1,
    "cm_step": CM_STEP,
    "expected_points": EXPECTED_POINTS,
}

# Modèles à charger automatiquement
MODEL_PATH1 = os.path.join("models", "mask_rcnn_trained_3.pth")
MODEL_PATH2 = os.path.join("models", "mask_rcnn_trained2.pth")


# ===================== UTILS ===================== #
def list_image_files(folder: str) -> List[str]:
    if not os.path.isdir(folder):
        return []
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    return sorted([f for f in os.listdir(folder)
                   if os.path.isfile(os.path.join(folder, f))
                   and os.path.splitext(f.lower())[1] in exts])


def parse_image_name(fname: str) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    base = os.path.basename(fname)
    m = re.match(r'^(?P<chantier>.+?)_P[Kk](?P<start>\d+)[_-](?P<end>\d+)(?:\.[^.]+)?$', base)
    if not m:
        return None, None, None
    chantier = m.group("chantier")
    try:
        pk_start_cm = int(m.group("start")) * 100
        pk_end_cm   = int(m.group("end"))   * 100
    except Exception:
        return chantier, None, None
    return chantier, pk_start_cm, pk_end_cm


def classify_files_by_pk(files: List[str]) -> Tuple[List[str], List[str], List[str]]:
    asc, desc, unknown = [], [], []
    for f in files:
        _, s, e = parse_image_name(f)
        if s is None or e is None or s == e:
            unknown.append(f)
        elif e > s:
            asc.append(f)
        else:
            desc.append(f)
    return asc, desc, unknown


def has_existing_inference(cat_root: str) -> Dict[str, object]:
    excels_dir = os.path.join(cat_root, "excels")
    exists = os.path.isdir(excels_dir)
    num_excels = 0
    if exists:
        for f in os.listdir(excels_dir):
            if f.lower().endswith(".xlsx"):
                num_excels += 1
    return {"exists": exists and num_excels > 0, "num_excels": num_excels}


# ===================== Modèle ===================== #
def _get_model_instance_segmentation(num_classes: int = 2):
    model = maskrcnn_resnet50_fpn(weights=None)
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    in_features_mask = model.roi_heads.mask_predictor.conv5_mask.in_channels
    model.roi_heads.mask_predictor = MaskRCNNPredictor(in_features_mask, 256, num_classes)
    return model


# ===================== Profils ===================== #
def _y_profile_from_mask(mask_uint8: np.ndarray, x_px_grid: np.ndarray) -> np.ndarray:
    ys = np.full(len(x_px_grid), np.nan, dtype=float)
    for i, x in enumerate(x_px_grid):
        col = mask_uint8[:, x] > 0
        if np.any(col):
            ys[i] = float(np.min(np.where(col)[0]))  # frontière sup
    return ys


def _order_interfaces_top_down(fused_masks: List[np.ndarray]) -> List[np.ndarray]:
    scored = []
    for m in fused_masks:
        ys, xs = np.where(m > 0)
        if xs.size == 0 or ys.size == 0:
            continue
        w = int(xs.max() - xs.min() + 1)
        if w < MIN_WIDTH_PX:
            continue
        y_min = int(np.min(ys)) if ys.size else 10**9
        scored.append((y_min, m))
        # petit garde-fou : si jamais pas de pixels, on skip déjà au-dessus
    scored.sort(key=lambda t: t[0])
    return [m for _, m in scored]


# ===================== Fusion & Filtrage ===================== #
def _fuse_close_masks(
    masks: List[np.ndarray],
    dilate_iter: int,
    kernel_size: Tuple[int, int],
    horiz_boost: bool,
    hlen: int,
    hthick: int,
    hclose_iter: int
) -> List[np.ndarray]:
    if not masks:
        return []
    H, W = masks[0].shape[:2]
    combined = np.zeros((H, W), dtype=np.uint8)
    for m in masks:
        combined = cv2.bitwise_or(combined, (m > 0).astype(np.uint8) * 255)

    work = combined.copy()
    if horiz_boost and hlen > 1 and hthick > 0 and hclose_iter > 0:
        h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (int(hlen), int(hthick)))
        work = cv2.dilate(work, h_kernel, iterations=int(hclose_iter))
        work = cv2.erode(work,  h_kernel, iterations=int(hclose_iter))

    kx, ky = kernel_size
    iso_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(1, int(kx)), max(1, int(ky))))
    if dilate_iter > 0:
        work = cv2.dilate(work, iso_kernel, iterations=int(dilate_iter))

    contours, _ = cv2.findContours(work, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    fused = []
    for cnt in contours:
        cnt = np.ascontiguousarray(cnt, dtype=np.int32)
        mask = np.zeros((H, W), dtype=np.uint8)
        cv2.drawContours(mask, [cnt], -1, 255, -1)
        fused.append(mask)
    return fused


def _filter_interfaces(
    masks: List[np.ndarray],
    aspect_ratio_thr: float = ASPECT_RATIO_THR,
    min_height: int = MIN_HEIGHT_PX,
    min_width: int = MIN_WIDTH_PX
) -> List[np.ndarray]:
    filtered = []
    for m in masks:
        ys, xs = np.where(m > 0)
        if xs.size == 0 or ys.size == 0:
            continue
        w = int(xs.max() - xs.min() + 1)
        h = int(ys.max() - ys.min() + 1)
        if h < min_height or w < min_width or w / max(1, h) > aspect_ratio_thr:
            continue
        filtered.append(m)
    return filtered


def _apply_interface_thresholds(masks: List[np.ndarray]) -> List[np.ndarray]:
    """
    Supprime les masques dont la frontière supérieure (y_min)
    se situe dans la zone interdite [THR_INTERFACE0, THR_FORBIDDEN1].
    """
    kept = []
    for m in masks:
        ys, xs = np.where(m > 0)
        if xs.size == 0 or ys.size == 0:
            continue
        y_min = float(np.min(ys))   # frontière supérieure
        if THR_INTERFACE0 <= y_min <= THR_FORBIDDEN1:
            continue
        kept.append(m)
    return kept


# ===================== EXPORTS ===================== #
def _save_visuals(image_rgb: np.ndarray, fname: str, pred_instances: List[np.ndarray],
                  dir_overlays: str, dir_pred_masks: str, dir_pred_color: str) -> None:
    H, W = image_rgb.shape[:2]

    overlay = image_rgb.copy()
    for m in pred_instances:
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, cnts, -1, (255, 0, 0), 2)
    cv2.imwrite(os.path.join(dir_overlays, fname), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR))

    pred_combined = np.zeros((H, W), dtype=np.uint8)
    for m in pred_instances:
        pred_combined = cv2.bitwise_or(pred_combined, (m > 0).astype(np.uint8) * 255)
    cv2.imwrite(os.path.join(dir_pred_masks, fname), pred_combined)

    colored = cv2.applyColorMap(pred_combined, cv2.COLORMAP_JET)
    blend = cv2.addWeighted(image_rgb, 0.7, colored, 0.3, 0)
    cv2.imwrite(os.path.join(dir_pred_color, fname), cv2.cvtColor(blend, cv2.COLOR_RGB2BGR))


def _write_positions_json_per_image(
    out_dir_positions: str, fname: str, chantier: Optional[str],
    pk_start_cm: Optional[int], pk_end_cm: Optional[int], fused_masks: List[np.ndarray]
) -> str:
    if len(fused_masks) == 0:
        pixels = []
        H = W = None
    else:
        H, W = fused_masks[0].shape[:2]
        combined = np.zeros((H, W), dtype=np.uint8)
        for m in fused_masks:
            combined = cv2.bitwise_or(combined, (m > 0).astype(np.uint8) * 255)
        pixels = []
        for x in range(W):
            col = np.where(combined[:, x] > 0)[0]
            if col.size > 0:
                pixels.append([int(x), int(col.min())])

    payload = {
        "image": fname,
        "chantier": chantier,
        "pk_start_cm": None if pk_start_cm is None else int(pk_start_cm),
        "pk_end_cm": None if pk_end_cm is None else int(pk_end_cm),
        "pixels": pixels,
        "height_px": int(H) if H is not None else None,
        "width_px": int(W) if W is not None else None,
    }
    os.makedirs(out_dir_positions, exist_ok=True)
    out_path = os.path.join(out_dir_positions, os.path.splitext(fname)[0] + ".json")
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    return out_path


def _write_interfaces_excel(
    out_dir_excels: str, fname: str, chantier: Optional[str],
    pk_start_cm: Optional[int], pk_end_cm: Optional[int],
    fused_masks: List[np.ndarray], image_shape: Tuple[int, int, int]
) -> Optional[str]:
    if chantier is None or pk_start_cm is None or pk_end_cm is None or pk_start_cm == pk_end_cm:
        return None

    H, W = image_shape[:2]
    x_cm_grid = np.linspace(pk_start_cm, pk_end_cm, EXPECTED_POINTS, endpoint=False, dtype=np.int64)
    if x_cm_grid.size == 0:
        return None
    x_px_grid = np.rint((x_cm_grid - pk_start_cm) / (pk_end_cm - pk_start_cm) * (W - 1)).astype(int)
    x_px_grid = np.clip(x_px_grid, 0, W - 1)

    masks_sorted = _order_interfaces_top_down(fused_masks)
    data = {"x_cm": x_cm_grid.astype(int)}

    if len(masks_sorted) == 0:
        data["interface_0"] = [np.nan] * len(x_cm_grid)
    else:
        profiles, medians = [], []
        for m in masks_sorted:
            prof = _y_profile_from_mask(m, x_px_grid)
            profiles.append(prof)
            med = np.nanmedian(prof)
            medians.append(med if np.isfinite(med) else np.nan)

        group0_idx = [i for i, med in enumerate(medians) if np.isfinite(med) and med <= THR_INTERFACE0]
        forbidden_idx = [i for i, med in enumerate(medians) if np.isfinite(med) and THR_INTERFACE0 < med < THR_FORBIDDEN1]
        remaining_idx = [i for i in range(len(profiles)) if i not in group0_idx and i not in forbidden_idx]

        if group0_idx:
            stack = np.vstack([profiles[i] for i in group0_idx])
            data["interface_0"] = np.nanmean(stack, axis=0)
            start_num = 1
        else:
            start_num = 1

        for out_i, idx in enumerate(remaining_idx, start=start_num):
            data[f"interface_{out_i}"] = profiles[idx]

    df = pd.DataFrame(data)
    os.makedirs(out_dir_excels, exist_ok=True)
    excel_path = os.path.join(out_dir_excels, os.path.splitext(fname)[0] + ".xlsx")
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="interfaces", index=False)
    return excel_path


# ===================== Agrégation ===================== #
def aggregate_excels_to_stratigraphy(excels_dir: str, sort_order: str = "ASC") -> Optional[pd.DataFrame]:
    if not os.path.isdir(excels_dir):
        return None
    frames = []
    for f in os.listdir(excels_dir):
        if f.lower().endswith(".xlsx"):
            p = os.path.join(excels_dir, f)
            try:
                df = pd.read_excel(p, sheet_name="interfaces")
                if "x_cm" in df.columns:
                    df["x_cm"] = pd.to_numeric(df["x_cm"], errors="coerce")
                frames.append(df)
            except Exception:
                continue
    if not frames:
        return None
    out = pd.concat(frames, axis=0, ignore_index=True)
    if "x_cm" in out.columns:
        out = out.dropna(subset=["x_cm"])
        out["x_cm"] = pd.to_numeric(out["x_cm"], errors="coerce")
        out = out.sort_values("x_cm").reset_index(drop=True)
    return out


# ===================== Inférence principale ===================== #
def run_inference_for_category(
    image_folder: str,
    files: List[str],
    model_path: str,  # ignoré → on charge 2 modèles auto
    output_root: str,
    category: str,
    params: Dict[str, object],
    force: bool = True
) -> Dict[str, object]:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    cat_root = os.path.join(output_root, category)
    dir_overlays   = os.path.join(cat_root, "overlays")
    dir_pred_masks = os.path.join(cat_root, "pred_masks")
    dir_pred_color = os.path.join(cat_root, "pred_colormap")
    dir_positions  = os.path.join(cat_root, "positions")
    dir_excels     = os.path.join(cat_root, "excels")
    for d in [dir_overlays, dir_pred_masks, dir_pred_color, dir_positions, dir_excels]:
        os.makedirs(d, exist_ok=True)

    # Charger les deux modèles
    model1 = _get_model_instance_segmentation(2)
    model2 = _get_model_instance_segmentation(2)
    state1 = torch.load(MODEL_PATH1, map_location=device)
    state2 = torch.load(MODEL_PATH2, map_location=device)
    model1.load_state_dict(state1); model1.to(device).eval()
    model2.load_state_dict(state2); model2.to(device).eval()

    num_images = 0
    for fname in files:
        img_path = os.path.join(image_folder, fname)
        try:
            rgb = np.array(Image.open(img_path).convert("RGB"))
        except Exception:
            continue

        tens = torch.from_numpy(rgb).permute(2, 0, 1).float() / 255.0
        tens = tens.unsqueeze(0).to(device)

        with torch.no_grad():
            out1 = model1(tens)[0]
            out2 = model2(tens)[0]

        chosen: List[np.ndarray] = []
        for out in [out1, out2]:
            scores, masks = out.get("scores"), out.get("masks")
            if scores is not None and masks is not None:
                scores = scores.detach().cpu().numpy()
                probs = masks.detach().cpu().numpy()[:, 0, :, :]
                for s, prob in zip(scores, probs):
                    if s >= float(params.get("score_thr", DEFAULT_PARAMS["score_thr"])):
                        binm = (prob > float(params.get("pixel_thr", DEFAULT_PARAMS["pixel_thr"]))).astype(np.uint8) * 255
                        chosen.append(binm)

        # --- Pipeline : filtrage → seuils → fusion → re-filtrage → re-seuils (pour overlays/exports cohérents)
        chosen = _filter_interfaces(chosen)           # largeur min 100 px, ratio, etc.
        chosen = _apply_interface_thresholds(chosen)  # supprime si y_min ∈ [38, 52]

        chosen = _fuse_close_masks(
            chosen,
            dilate_iter=int(params.get("fuse_dilate_iter", DEFAULT_PARAMS["fuse_dilate_iter"])),
            kernel_size=tuple(params.get("fuse_kernel_size", DEFAULT_PARAMS["fuse_kernel_size"])),
            horiz_boost=bool(params.get("fuse_horizontal_boost", DEFAULT_PARAMS["fuse_horizontal_boost"])),
            hlen=int(params.get("hline_len", DEFAULT_PARAMS["hline_len"])),
            hthick=int(params.get("hline_thick", DEFAULT_PARAMS["hline_thick"])),
            hclose_iter=int(params.get("hline_close_iters", DEFAULT_PARAMS["hline_close_iters"]))
        )

        # Passes finales pour overlays strictement conformes aux règles
        chosen = _filter_interfaces(chosen)           # re-applique largeur min = 100 px, etc.
        chosen = _apply_interface_thresholds(chosen)  # re-supprime y_min ∈ [38, 52] après fusion

        chantier, pk_start_cm, pk_end_cm = parse_image_name(fname)

        # Exports (utilisent uniquement les masques "chosen" déjà filtrés)
        _save_visuals(rgb, fname, chosen, dir_overlays, dir_pred_masks, dir_pred_color)
        _write_positions_json_per_image(dir_positions, fname, chantier, pk_start_cm, pk_end_cm, chosen)
        _write_interfaces_excel(dir_excels, fname, chantier, pk_start_cm, pk_end_cm, chosen, rgb.shape)

        num_images += 1

    return {"skipped_due_to_existing": False, "num_images": num_images}
